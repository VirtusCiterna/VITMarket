VITMarket - Ready for Windows

IMPORTANT:
Do NOT double-click the React source index.html and do not run npm just to view the
offline copy.

To open the complete website:
1. Extract this ZIP.
2. Open the VITMarket-Ready folder.
3. Double-click "START VITMARKET.bat".
4. Your browser should open http://127.0.0.1:5173/
5. Keep the black/PowerShell window open while using the website.
6. Press Ctrl+C in that window when finished.

Campus map:
- Click the green "Campus map" button at the bottom right of the website,
  or open http://127.0.0.1:5173/campus-map.html directly.
- Drag to pan, scroll or pinch to zoom, search for a block, and tap a pin
  to see the walk from where you are standing.
- The "Add a store" tab lets you drop a pin on the exact shop and save it.
  Pins are stored in your browser, so they stay after you close the window.

This package includes:
- The compiled VITMarket website in VITMarket-Website/
- All original React/Vite source in src/
- package.json and project configuration
- Offline API/data used by the app
- A Windows PowerShell server, so Node.js and Python are NOT required

The previous launcher depended on Python. This version does not.
