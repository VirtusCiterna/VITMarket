$ErrorActionPreference = "Stop"
$Root = Join-Path $PSScriptRoot "VITMarket-Website"
$Port = 5173
$Prefix = "http://127.0.0.1:$Port/"
$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add($Prefix)
try {
    $listener.Start()
} catch {
    Write-Host ""
    Write-Host "Could not start VITMarket."
    Write-Host "Port $Port may already be in use."
    Write-Host $_.Exception.Message
    Read-Host "Press Enter to close"
    exit 1
}

Start-Process $Prefix
Write-Host "VITMarket is running at $Prefix"
Write-Host "Keep this window open while using the website."
Write-Host "Press Ctrl+C here when you are finished."
Write-Host ""

$mime = @{
    ".html"="text/html; charset=utf-8"
    ".css"="text/css; charset=utf-8"
    ".js"="text/javascript; charset=utf-8"
    ".json"="application/json; charset=utf-8"
    ".svg"="image/svg+xml"
    ".png"="image/png"
    ".jpg"="image/jpeg"
    ".jpeg"="image/jpeg"
    ".webp"="image/webp"
    ".ico"="image/x-icon"
    ".txt"="text/plain; charset=utf-8"
    ".woff"="font/woff"
    ".woff2"="font/woff2"
}

while ($listener.IsListening) {
    try {
        $ctx = $listener.GetContext()
        $path = [System.Uri]::UnescapeDataString($ctx.Request.Url.AbsolutePath)
        if ([string]::IsNullOrWhiteSpace($path) -or $path -eq "/") {
            $path = "/index.html"
        }

        $relative = $path.TrimStart("/") -replace "/", "\"
        $candidate = Join-Path $Root $relative

        # React/Wouter hash routes normally stay at "/", but this also makes
        # ordinary paths fall back to index.html instead of a server 404.
        if (-not (Test-Path -LiteralPath $candidate -PathType Leaf)) {
            $candidate = Join-Path $Root "index.html"
        }

        $bytes = [System.IO.File]::ReadAllBytes($candidate)
        $ext = [System.IO.Path]::GetExtension($candidate).ToLowerInvariant()
        if ($mime.ContainsKey($ext)) {
            $ctx.Response.ContentType = $mime[$ext]
        } else {
            $ctx.Response.ContentType = "application/octet-stream"
        }
        $ctx.Response.StatusCode = 200
        $ctx.Response.ContentLength64 = $bytes.Length
        $ctx.Response.OutputStream.Write($bytes, 0, $bytes.Length)
        $ctx.Response.OutputStream.Close()
    } catch {
        try { $ctx.Response.StatusCode = 500; $ctx.Response.Close() } catch {}
    }
}
