import { useMemo, useState } from 'react';
import { Link } from 'wouter';
import { Check, MapPin, Trash2 } from 'lucide-react';
import { getListStoresQueryKey, useListStores } from '@workspace/api-client-react';
import { CampusMap, type MapPin as Pin } from '@/components/campus-map';
import {
  CATEGORY_META, describePoint, matchLandmark, pinnedStores,
  type CampusCategory, type CampusPoint,
} from '@/lib/campus-map';
import { usePinnedStores } from '@/pages/campus-map-page';
import { demoStores } from '@/App';

const CATEGORY_CHOICES: CampusCategory[] = ['store', 'food', 'service'];

export default function AddLocationPage() {
  const { data } = useListStores({ query: { queryKey: getListStoresQueryKey() } });
  const stores = (data as any[]) || demoStores;
  const saved = usePinnedStores();

  const [point, setPoint] = useState<CampusPoint | null>(null);
  const [storeId, setStoreId] = useState<string>('new');
  const [name, setName] = useState('');
  const [category, setCategory] = useState<CampusCategory>('store');
  const [note, setNote] = useState('');
  const [hours, setHours] = useState('');
  const [phone, setPhone] = useState('');
  const [justSaved, setJustSaved] = useState<string | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);

  const place = point ? describePoint(point) : null;

  const existingPins: Pin[] = saved.map((pin) => ({
    id: pin.id,
    name: pin.name,
    category: pin.category,
    detail: pin.note || pin.place,
    x: pin.x,
    y: pin.y,
    mine: true,
  }));

  const chosenStore = storeId === 'new' ? null : stores.find((store) => String(store.id) === storeId);

  const pickStore = (value: string) => {
    setStoreId(value);
    setJustSaved(null);
    const store = stores.find((item) => String(item.id) === value);
    if (!store) return;
    setName(store.name);
    setHours(store.hours || '');
    setPhone(store.phone || '');
    setNote(store.location || '');
    if (!point) {
      const landmark = matchLandmark(store.location);
      if (landmark) setPoint({ x: landmark.x, y: landmark.y });
    }
  };

  const reset = () => {
    setPoint(null); setStoreId('new'); setName(''); setNote(''); setHours(''); setPhone('');
    setCategory('store'); setEditingId(null);
  };

  const save = (event: React.FormEvent) => {
    event.preventDefault();
    if (!point || !name.trim()) return;
    const payload = {
      name: name.trim(),
      category,
      note: note.trim() || undefined,
      hours: hours.trim() || undefined,
      phone: phone.trim() || undefined,
      storeId: chosenStore ? chosenStore.id : undefined,
      x: point.x,
      y: point.y,
      place: describePoint(point),
    };
    if (editingId) {
      pinnedStores.update(editingId, payload);
      setJustSaved(`${payload.name} moved to ${payload.place.toLowerCase()}.`);
    } else {
      pinnedStores.add(payload);
      setJustSaved(`${payload.name} is on the map, ${payload.place.toLowerCase()}.`);
    }
    reset();
  };

  const startEdit = (id: string) => {
    const pin = saved.find((item) => item.id === id);
    if (!pin) return;
    setEditingId(pin.id);
    setPoint({ x: pin.x, y: pin.y });
    setName(pin.name);
    setCategory(pin.category);
    setNote(pin.note || '');
    setHours(pin.hours || '');
    setPhone(pin.phone || '');
    setStoreId(pin.storeId ? String(pin.storeId) : 'new');
    setJustSaved(null);
  };

  const unpinned = useMemo(
    () => stores.filter((store) => !saved.some((pin) => pin.storeId === store.id)),
    [stores, saved],
  );

  return (
    <div className="space-y-7">
      <div>
        <h1 className="font-display text-4xl font-bold tracking-tight sm:text-5xl">Put a store on the map</h1>
        <p className="mt-3 max-w-2xl text-muted-foreground">
          Find the building on the campus map, tap the exact spot, and fill in the details. Students will see the pin
          and the walk from wherever they are.
        </p>
      </div>

      <div className="grid gap-5 lg:grid-cols-[1.4fr_1fr]">
        <div className="space-y-3">
          <CampusMap
            pins={existingPins}
            mode="pick"
            picked={point}
            onPick={(next) => { setPoint(next); setJustSaved(null); }}
            height="min(66vh, 600px)"
          />
          <p className="text-xs text-muted-foreground">
            Search for a block to jump to it, zoom in with the buttons or a pinch, then tap the shop front. Drag the
            map to move around; tap again to correct the pin.
          </p>
        </div>

        <form onSubmit={save} className="space-y-4 rounded-2xl border border-border bg-card p-5">
          <div className={`rounded-xl border p-3 ${point ? 'border-primary/30 bg-primary/[.06]' : 'border-dashed border-border bg-muted/40'}`}>
            <p className="flex items-center gap-2 text-sm font-semibold">
              <MapPin size={15} className={point ? 'text-primary' : 'text-muted-foreground'} />
              {point ? place : 'No spot chosen yet'}
            </p>
            <p className="mt-1 text-xs text-muted-foreground">
              {point ? 'Tap the map again to move the pin.' : 'Tap the map to drop the pin.'}
            </p>
          </div>

          <label className="block text-sm font-semibold">
            Which store is this?
            <select
              value={storeId}
              onChange={(event) => pickStore(event.target.value)}
              data-testid="select-location-store"
              className="mt-2 w-full rounded-xl border border-input bg-background px-3 py-2.5 text-sm"
            >
              <option value="new">A store that is not listed yet</option>
              {stores.map((store) => (
                <option key={store.id} value={store.id}>{store.name}</option>
              ))}
            </select>
          </label>

          <label className="block text-sm font-semibold">
            Name
            <input
              required
              value={name}
              onChange={(event) => setName(event.target.value)}
              data-testid="input-location-name"
              placeholder="e.g. Tech Stop"
              className="mt-2 w-full rounded-xl border border-input bg-background px-3 py-2.5 text-sm outline-none focus:border-primary"
            />
          </label>

          <div className="text-sm font-semibold">
            Type
            <div className="mt-2 flex gap-2">
              {CATEGORY_CHOICES.map((choice) => (
                <button
                  key={choice}
                  type="button"
                  onClick={() => setCategory(choice)}
                  data-testid={`button-location-category-${choice}`}
                  className={`flex-1 rounded-xl border px-3 py-2 text-xs font-semibold transition ${
                    category === choice ? 'border-primary bg-primary/10 text-primary' : 'border-border text-muted-foreground'
                  }`}
                >
                  {CATEGORY_META[choice].short}
                </button>
              ))}
            </div>
          </div>

          <label className="block text-sm font-semibold">
            Where exactly, in words
            <input
              value={note}
              onChange={(event) => setNote(event.target.value)}
              data-testid="input-location-note"
              placeholder="SJT ground floor, left of the lift"
              className="mt-2 w-full rounded-xl border border-input bg-background px-3 py-2.5 text-sm outline-none focus:border-primary"
            />
          </label>

          <div className="grid grid-cols-2 gap-3">
            <label className="block text-sm font-semibold">
              Hours
              <input
                value={hours}
                onChange={(event) => setHours(event.target.value)}
                data-testid="input-location-hours"
                placeholder="9:00 AM – 9:00 PM"
                className="mt-2 w-full rounded-xl border border-input bg-background px-3 py-2.5 text-sm outline-none focus:border-primary"
              />
            </label>
            <label className="block text-sm font-semibold">
              Phone
              <input
                value={phone}
                onChange={(event) => setPhone(event.target.value)}
                data-testid="input-location-phone"
                placeholder="Optional"
                className="mt-2 w-full rounded-xl border border-input bg-background px-3 py-2.5 text-sm outline-none focus:border-primary"
              />
            </label>
          </div>

          <button
            disabled={!point || !name.trim()}
            data-testid="button-save-location"
            className="w-full rounded-xl bg-primary py-3 text-sm font-bold text-primary-foreground transition hover:bg-primary/90 disabled:cursor-not-allowed disabled:opacity-50"
          >
            {editingId ? 'Save the new spot' : 'Save this location'}
          </button>

          {justSaved && (
            <p data-testid="text-location-saved" className="flex items-center gap-2 rounded-xl bg-primary/10 px-3 py-2.5 text-xs font-semibold text-primary">
              <Check size={14} /> {justSaved} <Link href="/map" className="ml-auto underline">See it</Link>
            </p>
          )}
        </form>
      </div>

      <section className="grid gap-5 lg:grid-cols-[1.4fr_1fr]">
        <div>
          <h2 className="font-display text-xl font-bold">Locations you have pinned</h2>
          {saved.length === 0 ? (
            <p className="mt-3 rounded-xl border border-dashed border-border bg-muted/40 p-4 text-sm text-muted-foreground">
              Nothing pinned yet. The first one you save shows up here and on the campus map.
            </p>
          ) : (
            <ul className="mt-3 space-y-2">
              {saved.map((pin) => (
                <li
                  key={pin.id}
                  data-testid={`row-pinned-${pin.id}`}
                  className="flex items-center gap-3 rounded-xl border border-border bg-card p-3"
                >
                  <span
                    className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg text-white"
                    style={{ backgroundColor: CATEGORY_META[pin.category].color }}
                  >
                    <MapPin size={15} />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate font-semibold">{pin.name}</span>
                    <span className="block truncate text-xs text-muted-foreground">{pin.note || pin.place}</span>
                  </span>
                  <button
                    type="button"
                    onClick={() => startEdit(pin.id)}
                    data-testid={`button-move-pin-${pin.id}`}
                    className="rounded-lg border border-border px-2.5 py-1.5 text-xs font-bold hover:border-primary/40 hover:text-primary"
                  >
                    Move
                  </button>
                  <button
                    type="button"
                    onClick={() => pinnedStores.remove(pin.id)}
                    aria-label={`Remove ${pin.name}`}
                    data-testid={`button-remove-pin-${pin.id}`}
                    className="flex h-8 w-8 items-center justify-center rounded-lg text-muted-foreground hover:bg-accent/10 hover:text-accent"
                  >
                    <Trash2 size={14} />
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>

        {unpinned.length > 0 && (
          <div className="rounded-2xl border border-border bg-muted/30 p-5">
            <h2 className="font-display text-lg font-bold">Still waiting for a pin</h2>
            <ul className="mt-3 space-y-2 text-sm">
              {unpinned.map((store) => (
                <li key={store.id} className="flex items-center justify-between gap-3">
                  <span className="min-w-0">
                    <span className="block truncate font-semibold">{store.name}</span>
                    <span className="block truncate text-xs text-muted-foreground">{store.location}</span>
                  </span>
                  <button
                    type="button"
                    onClick={() => pickStore(String(store.id))}
                    data-testid={`button-pin-store-${store.id}`}
                    className="shrink-0 rounded-lg bg-primary px-3 py-1.5 text-xs font-bold text-primary-foreground"
                  >
                    Pin it
                  </button>
                </li>
              ))}
            </ul>
            <p className="mt-3 text-xs text-muted-foreground">
              Their map position is guessed from the block name until someone drops a real pin.
            </p>
          </div>
        )}
      </section>
    </div>
  );
}
