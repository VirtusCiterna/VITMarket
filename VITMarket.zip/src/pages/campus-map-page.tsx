import { useMemo, useState, useSyncExternalStore } from 'react';
import { Link } from 'wouter';
import { Navigation, Store as StoreIcon } from 'lucide-react';
import { getListStoresQueryKey, useListStores } from '@workspace/api-client-react';
import { CampusMap, useMyLocation, type MapPin as Pin } from '@/components/campus-map';
import {
  CATEGORY_META, CAMPUS_LANDMARKS, formatDistance, isOnCampus, matchLandmark, metresBetween,
  pinnedStores, walkMinutes, type CampusCategory, type CampusPoint,
} from '@/lib/campus-map';
import { demoStores } from '@/App';

export function usePinnedStores() {
  return useSyncExternalStore(pinnedStores.subscribe, pinnedStores.list, () => []);
}

const MAIN_GATE = CAMPUS_LANDMARKS.find((item) => item.id === 'gate-main')!;

function categoryForStore(store: any): CampusCategory {
  const categories: string[] = store.categories || [];
  if (categories.some((item) => /food|drink|cafe/i.test(item))) return 'food';
  return 'store';
}

export default function CampusMapPage() {
  const { data } = useListStores({ query: { queryKey: getListStoresQueryKey() } });
  const stores = (data as any[]) || demoStores;
  const pins = usePinnedStores();
  const me = useMyLocation();
  const origin = me && isOnCampus(me) ? me : MAIN_GATE;

  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [routeTo, setRouteTo] = useState<CampusPoint | null>(null);

  const { located, unlocated } = useMemo(() => {
    const locatedStores: Array<{ store: any; point: CampusPoint; source: 'pinned' | 'guessed'; place: string }> = [];
    const missing: any[] = [];
    for (const store of stores) {
      const pinned = pins.find((pin) => pin.storeId === store.id);
      if (pinned) {
        locatedStores.push({ store, point: { x: pinned.x, y: pinned.y }, source: 'pinned', place: pinned.note || pinned.place });
        continue;
      }
      const landmark = matchLandmark(store.location);
      if (landmark) {
        locatedStores.push({ store, point: { x: landmark.x, y: landmark.y }, source: 'guessed', place: landmark.name });
        continue;
      }
      missing.push(store);
    }
    return { located: locatedStores, unlocated: missing };
  }, [stores, pins]);

  const standalone = pins.filter((pin) => !pin.storeId);

  const mapPins: Pin[] = [
    ...located.map(({ store, point, source, place }) => ({
      id: `store-${store.id}`,
      name: store.name,
      category: categoryForStore(store),
      detail: place,
      x: point.x,
      y: point.y,
      mine: source === 'pinned',
      body: <StoreCardBody store={store} onDirections={() => setRouteTo(point)} />,
    })),
    ...standalone.map((pin) => ({
      id: pin.id,
      name: pin.name,
      category: pin.category,
      detail: pin.note || pin.place,
      x: pin.x,
      y: pin.y,
      mine: true,
      body: (
        <div className="mt-3 space-y-2 text-xs">
          {pin.hours && <p className="text-muted-foreground">Open {pin.hours}</p>}
          <button
            onClick={() => setRouteTo({ x: pin.x, y: pin.y })}
            className="flex w-full items-center justify-center gap-2 rounded-xl bg-primary py-2 text-xs font-bold text-primary-foreground"
          >
            <Navigation size={13} /> Walk here
          </button>
        </div>
      ),
    })),
  ];

  const sorted = [...located].sort((a, b) => metresBetween(origin, a.point) - metresBetween(origin, b.point));

  return (
    <div className="space-y-7">
      <div className="flex flex-col justify-between gap-5 lg:flex-row lg:items-end">
        <div>
          <p className="font-mono-app text-[10px] uppercase tracking-[.2em] text-primary">Where things are</p>
          <h1 className="mt-2 font-display text-5xl font-bold tracking-tight">Campus map</h1>
          <p className="mt-3 max-w-xl text-muted-foreground">
            Every store on the Vellore campus, on the real campus map. We find where you are standing and show the walk
            to whatever you tap or search for.
          </p>
        </div>
      </div>

      <div className="grid gap-5 lg:grid-cols-[1.55fr_.95fr]">
        <CampusMap
          pins={mapPins}
          selectedId={selectedId}
          onSelect={setSelectedId}
          routeTo={routeTo}
          onClearRoute={() => setRouteTo(null)}
          height="min(70vh, 640px)"
        />

        <div className="flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-lg font-bold">
              {me && isOnCampus(me) ? 'Closest to you' : 'From the Main Gate'}
            </h2>
            <span className="text-xs text-muted-foreground">{sorted.length} places</span>
          </div>

          <ul className="space-y-2 overflow-y-auto pr-1" style={{ maxHeight: 'min(56vh, 520px)' }}>
            {sorted.map(({ store, point, source, place }) => {
              const metres = metresBetween(origin, point);
              const id = `store-${store.id}`;
              return (
                <li key={store.id}>
                  <button
                    onClick={() => setSelectedId(id)}
                    data-testid={`button-map-list-${store.id}`}
                    className={`flex w-full items-start gap-3 rounded-xl border p-3 text-left transition ${
                      selectedId === id ? 'border-primary bg-primary/[.06]' : 'border-border bg-card hover:border-primary/35'
                    }`}
                  >
                    <span
                      className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-lg text-white"
                      style={{ backgroundColor: CATEGORY_META[categoryForStore(store)].color }}
                    >
                      <StoreIcon size={16} />
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="block truncate font-semibold">{store.name}</span>
                      <span className="mt-0.5 block truncate text-xs text-muted-foreground">{place}</span>
                      <span className="mt-1.5 flex items-center gap-2 text-xs">
                        <span className="font-semibold text-primary">{formatDistance(metres)}</span>
                        <span className="text-muted-foreground">{walkMinutes(metres)} min walk</span>
                        {source === 'guessed' && <span className="text-muted-foreground">· approximate</span>}
                      </span>
                    </span>
                  </button>
                </li>
              );
            })}
          </ul>

          {unlocated.length > 0 && (
            <div className="rounded-xl border border-dashed border-border bg-muted/40 p-4">
              <p className="text-sm font-semibold">
                {unlocated.length} {unlocated.length === 1 ? 'store has' : 'stores have'} no place on the map yet
              </p>
              <p className="mt-1 text-xs text-muted-foreground">
                {unlocated.map((store) => store.name).join(', ')}
              </p>
              <p className="mt-2 text-xs text-muted-foreground">Their spot can be pinned from the owner desk.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function StoreCardBody({ store, onDirections }: { store: any; onDirections: () => void }) {
  return (
    <div className="mt-3 space-y-2.5">
      <div className="flex items-center gap-2 text-xs">
        <span className={store.openNow ? 'font-semibold text-primary' : 'text-muted-foreground'}>
          {store.openNow ? 'Open now' : 'Closed'}
        </span>
        <span className="text-muted-foreground">· {store.hours || 'Hours not listed'}</span>
      </div>
      <div className="flex gap-2 pt-0.5">
        <button
          onClick={onDirections}
          data-testid={`button-map-directions-${store.id}`}
          className="flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-primary py-2 text-xs font-bold text-primary-foreground"
        >
          <Navigation size={13} /> Walk here
        </button>
        <Link
          href={`/stores/${store.id}`}
          className="flex flex-1 items-center justify-center rounded-xl border border-border py-2 text-xs font-bold hover:border-primary/40 hover:text-primary"
        >
          View store
        </Link>
      </div>
    </div>
  );
}
