import campusMapImage from '@/assets/campus-map.jpg';
import { type ReactNode, useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { Crosshair, Layers, Minus, Plus, Maximize2, Navigation, Search, X } from 'lucide-react';
import {
  CAMPUS_LANDMARKS, CATEGORY_META, formatDistance, isOnCampus, latLngToPoint, metresBetween,
  nearestLandmark, searchLandmarks, walkMinutes,
  type CampusCategory, type CampusLandmark, type CampusPoint,
} from '@/lib/campus-map';

const MAP_IMAGE = campusMapImage;
const IMAGE_RATIO = 913 / 1280;
const MAIN_GATE = CAMPUS_LANDMARKS.find((item) => item.id === 'gate-main')!;
const MIN_ZOOM = 1;
const MAX_ZOOM = 6;

export interface MapPin extends CampusPoint {
  id: string;
  name: string;
  category: CampusCategory;
  detail?: string;
  /** Rendered inside the pin card when the pin is selected. */
  body?: ReactNode;
  /** Pins added by a user are drawn with a ring so they read as "yours". */
  mine?: boolean;
}

interface CampusMapProps {
  pins?: MapPin[];
  selectedId?: string | null;
  onSelect?: (id: string | null) => void;
  /** 'browse' pans and selects. 'pick' drops a pin wherever the map is tapped. */
  mode?: 'browse' | 'pick';
  picked?: CampusPoint | null;
  onPick?: (point: CampusPoint) => void;
  /** Destination for the walking line. */
  routeTo?: CampusPoint | null;
  onClearRoute?: () => void;
  height?: string;
  showLandmarks?: boolean;
  className?: string;
  /** Centre the map here on first render, e.g. a single store. */
  focus?: CampusPoint | null;
  focusZoom?: number;
  /** 'minimal' hides the search field and layer switch, for small embedded maps. */
  chrome?: 'full' | 'minimal';
}

interface View {
  zoom: number;
  x: number;
  y: number;
}

export function CampusMap({
  pins = [],
  selectedId = null,
  onSelect,
  mode = 'browse',
  picked = null,
  onPick,
  routeTo = null,
  onClearRoute,
  height = '520px',
  showLandmarks = true,
  className = '',
  focus = null,
  focusZoom = 3.4,
  chrome = 'full',
}: CampusMapProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [size, setSize] = useState({ width: 0, height: 0 });
  const [view, setView] = useState<View>({ zoom: 1, x: 0, y: 0 });
  const [animate, setAnimate] = useState(false);
  const [query, setQuery] = useState('');
  const [hidden, setHidden] = useState<Set<CampusCategory>>(new Set());
  const [showLayers, setShowLayers] = useState(false);
  const [me, setMe] = useState<CampusPoint | null>(null);
  const [accuracy, setAccuracy] = useState<number | null>(null);
  const [locateState, setLocateState] = useState<'locating' | 'here' | 'off-campus' | 'denied'>('locating');
  const [hoveredId, setHoveredId] = useState<string | null>(null);
  const [landmarkId, setLandmarkId] = useState<string | null>(null);

  /* ---------------- sizing ---------------- */
  useLayoutEffect(() => {
    const node = containerRef.current;
    if (!node) return;
    const observer = new ResizeObserver(([entry]) => {
      setSize({ width: entry.contentRect.width, height: entry.contentRect.height });
    });
    observer.observe(node);
    setSize({ width: node.clientWidth, height: node.clientHeight });
    return () => observer.disconnect();
  }, []);

  // The whole campus fits the frame at zoom 1.
  const base = useMemo(() => {
    if (!size.width || !size.height) return { width: 0, height: 0 };
    const byWidth = { width: size.width, height: size.width * IMAGE_RATIO };
    return byWidth.height <= size.height ? byWidth : { width: size.height / IMAGE_RATIO, height: size.height };
  }, [size]);

  const clamp = useCallback(
    (next: View): View => {
      const width = base.width * next.zoom;
      const height = base.height * next.zoom;
      const x = width <= size.width ? (size.width - width) / 2 : Math.min(0, Math.max(size.width - width, next.x));
      const y = height <= size.height ? (size.height - height) / 2 : Math.min(0, Math.max(size.height - height, next.y));
      return { zoom: next.zoom, x, y };
    },
    [base, size],
  );

  useEffect(() => {
    setView((current) => clamp(current));
  }, [clamp]);

  const toPixels = useCallback(
    (point: CampusPoint) => ({
      left: point.x * base.width * view.zoom + view.x,
      top: point.y * base.height * view.zoom + view.y,
    }),
    [base, view],
  );

  const toPoint = useCallback(
    (clientX: number, clientY: number): CampusPoint => {
      const rect = containerRef.current!.getBoundingClientRect();
      return {
        x: (clientX - rect.left - view.x) / (base.width * view.zoom),
        y: (clientY - rect.top - view.y) / (base.height * view.zoom),
      };
    },
    [base, view],
  );

  /* ---------------- camera moves ---------------- */
  const zoomAround = useCallback(
    (factor: number, anchorX: number, anchorY: number, smooth = false) => {
      setAnimate(smooth);
      setView((current) => {
        const zoom = Math.min(MAX_ZOOM, Math.max(MIN_ZOOM, current.zoom * factor));
        const scale = zoom / current.zoom;
        return clamp({ zoom, x: anchorX - (anchorX - current.x) * scale, y: anchorY - (anchorY - current.y) * scale });
      });
    },
    [clamp],
  );

  const centerOn = useCallback(
    (point: CampusPoint, zoom = 3) => {
      setAnimate(true);
      setView(() =>
        clamp({
          zoom,
          x: size.width / 2 - point.x * base.width * zoom,
          y: size.height / 2 - point.y * base.height * zoom,
        }),
      );
    },
    [base, clamp, size],
  );

  const resetView = useCallback(() => {
    setAnimate(true);
    setView((current) => clamp({ ...current, zoom: 1 }));
  }, [clamp]);

  const focusedOnce = useRef(false);
  useEffect(() => {
    if (!focus || focusedOnce.current || !base.width) return;
    focusedOnce.current = true;
    centerOn(focus, focusZoom);
  }, [focus, focusZoom, base.width, centerOn]);

  /* ---------------- pointer input ---------------- */
  const pointers = useRef(new Map<number, { x: number; y: number }>());
  const dragStart = useRef({ x: 0, y: 0, viewX: 0, viewY: 0, moved: 0 });
  const pinchStart = useRef<{ distance: number; zoom: number } | null>(null);
  const [dragging, setDragging] = useState(false);

  const onPointerDown = (event: React.PointerEvent) => {
    if ((event.target as HTMLElement).closest('[data-map-ui]')) return;
    (event.target as HTMLElement).setPointerCapture?.(event.pointerId);
    pointers.current.set(event.pointerId, { x: event.clientX, y: event.clientY });
    if (pointers.current.size === 1) {
      setAnimate(false);
      setDragging(true);
      dragStart.current = { x: event.clientX, y: event.clientY, viewX: view.x, viewY: view.y, moved: 0 };
    } else if (pointers.current.size === 2) {
      const [a, b] = [...pointers.current.values()];
      pinchStart.current = { distance: Math.hypot(a.x - b.x, a.y - b.y), zoom: view.zoom };
    }
  };

  const onPointerMove = (event: React.PointerEvent) => {
    if (!pointers.current.has(event.pointerId)) return;
    pointers.current.set(event.pointerId, { x: event.clientX, y: event.clientY });

    if (pointers.current.size === 2 && pinchStart.current) {
      const [a, b] = [...pointers.current.values()];
      const distance = Math.hypot(a.x - b.x, a.y - b.y);
      const rect = containerRef.current!.getBoundingClientRect();
      const midX = (a.x + b.x) / 2 - rect.left;
      const midY = (a.y + b.y) / 2 - rect.top;
      const target = pinchStart.current.zoom * (distance / pinchStart.current.distance);
      setView((current) => {
        const zoom = Math.min(MAX_ZOOM, Math.max(MIN_ZOOM, target));
        const scale = zoom / current.zoom;
        return clamp({ zoom, x: midX - (midX - current.x) * scale, y: midY - (midY - current.y) * scale });
      });
      return;
    }

    if (!dragging) return;
    const dx = event.clientX - dragStart.current.x;
    const dy = event.clientY - dragStart.current.y;
    dragStart.current.moved = Math.max(dragStart.current.moved, Math.hypot(dx, dy));
    setView((current) => clamp({ ...current, x: dragStart.current.viewX + dx, y: dragStart.current.viewY + dy }));
  };

  const endPointer = (event: React.PointerEvent) => {
    const wasTracked = pointers.current.delete(event.pointerId);
    if (pointers.current.size < 2) pinchStart.current = null;
    if (!wasTracked || pointers.current.size > 0) return;
    setDragging(false);
    if (dragStart.current.moved > 5) return;

    // A tap, not a drag.
    if (mode === 'pick') {
      const point = toPoint(event.clientX, event.clientY);
      if (point.x >= 0 && point.x <= 1 && point.y >= 0 && point.y <= 1) onPick?.(point);
      return;
    }
    onSelect?.(null);
    setLandmarkId(null);
  };

  useEffect(() => {
    const node = containerRef.current;
    if (!node) return;
    const onWheel = (event: WheelEvent) => {
      event.preventDefault();
      const rect = node.getBoundingClientRect();
      zoomAround(event.deltaY < 0 ? 1.18 : 1 / 1.18, event.clientX - rect.left, event.clientY - rect.top);
    };
    node.addEventListener('wheel', onWheel, { passive: false });
    return () => node.removeEventListener('wheel', onWheel);
  }, [zoomAround]);

  const onKeyDown = (event: React.KeyboardEvent) => {
    const step = 70;
    const moves: Record<string, [number, number]> = {
      ArrowUp: [0, step], ArrowDown: [0, -step], ArrowLeft: [step, 0], ArrowRight: [-step, 0],
    };
    if (moves[event.key]) {
      event.preventDefault();
      const [dx, dy] = moves[event.key];
      setAnimate(true);
      setView((current) => clamp({ ...current, x: current.x + dx, y: current.y + dy }));
    }
    if (event.key === '+' || event.key === '=') zoomAround(1.3, size.width / 2, size.height / 2, true);
    if (event.key === '-') zoomAround(1 / 1.3, size.width / 2, size.height / 2, true);
  };

  /* ---------------- my location ---------------- */
  // The map looks for the person as soon as it opens, and keeps following them.
  useEffect(() => {
    if (!navigator.geolocation) return setLocateState('denied');
    const id = navigator.geolocation.watchPosition(
      (position) => {
        const point = latLngToPoint(position.coords.latitude, position.coords.longitude);
        setMe(point);
        setAccuracy(position.coords.accuracy ?? null);
        setLocateState(isOnCampus(point) ? 'here' : 'off-campus');
      },
      () => setLocateState('denied'),
      { enableHighAccuracy: true, timeout: 12000, maximumAge: 10000 },
    );
    return () => navigator.geolocation.clearWatch(id);
  }, []);

  const origin = me && isOnCampus(me) ? me : MAIN_GATE;
  const fromLabel = me && isOnCampus(me) ? 'from you' : 'from the Main Gate';
  const recentre = () => { if (me && isOnCampus(me)) centerOn(me, Math.max(view.zoom, 3.4)); };

  /* ---------------- data ---------------- */
  const visiblePins = pins.filter((pin) => !hidden.has(pin.category));
  const visibleLandmarks = showLandmarks
    ? CAMPUS_LANDMARKS.filter((landmark) => !hidden.has(landmark.category))
    : [];
  const selected = pins.find((pin) => pin.id === selectedId) || null;
  const selectedLandmark = landmarkId ? CAMPUS_LANDMARKS.find((item) => item.id === landmarkId) || null : null;
  const readout: MapPin | CampusLandmark | null = selected || selectedLandmark;
  const readoutMetres = readout ? metresBetween(origin, readout) : 0;
  const suggestions = searchLandmarks(query);
  const route = routeTo ? { from: origin, to: routeTo } : null;

  const labelZoom = view.zoom >= 2.2;

  return (
    <div
      className={`relative overflow-hidden rounded-2xl border border-border bg-[#dfe6dd] ${className}`}
      style={{ height }}
    >
      <div
        ref={containerRef}
        tabIndex={0}
        role="application"
        aria-label="VIT Vellore campus map"
        onKeyDown={onKeyDown}
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={endPointer}
        onPointerCancel={endPointer}
        onDoubleClick={(event) => {
          const rect = containerRef.current!.getBoundingClientRect();
          zoomAround(1.6, event.clientX - rect.left, event.clientY - rect.top, true);
        }}
        className={`absolute inset-0 touch-none outline-none focus-visible:ring-2 focus-visible:ring-primary ${
          mode === 'pick' ? 'cursor-crosshair' : dragging ? 'cursor-grabbing' : 'cursor-grab'
        }`}
      >
        <img
          src={MAP_IMAGE}
          alt="VIT Vellore campus map"
          draggable={false}
          onTransitionEnd={() => setAnimate(false)}
          style={{
            width: base.width || '100%',
            height: base.height || '100%',
            transform: `translate3d(${view.x}px, ${view.y}px, 0) scale(${view.zoom})`,
            transformOrigin: '0 0',
            transition: animate ? 'transform .28s cubic-bezier(.2,.8,.3,1)' : 'none',
          }}
          className="max-w-none select-none"
        />

        {/* Walking line */}
        {route && (
          <svg className="pointer-events-none absolute inset-0 h-full w-full">
            <line
              x1={toPixels(route.from).left}
              y1={toPixels(route.from).top}
              x2={toPixels(route.to).left}
              y2={toPixels(route.to).top}
              stroke="#0f766e"
              strokeWidth={4}
              strokeLinecap="round"
              strokeDasharray="1 10"
              opacity={0.85}
            />
          </svg>
        )}

        {/* Reference landmarks */}
        {visibleLandmarks.map((landmark) => {
          const { left, top } = toPixels(landmark);
          if (left < -80 || top < -80 || left > size.width + 80 || top > size.height + 80) return null;
          const meta = CATEGORY_META[landmark.category];
          const showLabel = labelZoom || hoveredId === landmark.id;
          return (
            <button
              key={landmark.id}
              data-map-ui
              type="button"
              onPointerDown={(event) => event.stopPropagation()}
              onClick={() => { setLandmarkId(landmark.id); onSelect?.(null); centerOn(landmark, Math.max(view.zoom, 3.2)); }}
              onMouseEnter={() => setHoveredId(landmark.id)}
              onMouseLeave={() => setHoveredId(null)}
              className="absolute z-10 flex -translate-x-1/2 -translate-y-1/2 items-center gap-1.5"
              style={{ left, top }}
              title={landmark.name}
            >
              <span
                className="h-2.5 w-2.5 shrink-0 rounded-full border-2 border-white shadow"
                style={{ backgroundColor: meta.color }}
              />
              {showLabel && (
                <span className="whitespace-nowrap rounded bg-white/85 px-1.5 py-0.5 text-[10px] font-semibold text-foreground shadow-sm backdrop-blur-sm">
                  {landmark.name}
                </span>
              )}
            </button>
          );
        })}

        {/* Store pins */}
        {visiblePins.map((pin) => {
          const { left, top } = toPixels(pin);
          if (left < -120 || top < -120 || left > size.width + 120 || top > size.height + 120) return null;
          const meta = CATEGORY_META[pin.category];
          const active = pin.id === selectedId;
          return (
            <button
              key={pin.id}
              data-map-ui
              type="button"
              onPointerDown={(event) => event.stopPropagation()}
              onClick={() => {
                onSelect?.(active ? null : pin.id);
                if (!active) centerOn(pin, Math.max(view.zoom, 2.6));
              }}
              aria-label={pin.name}
              aria-pressed={active}
              className={`absolute z-20 -translate-x-1/2 -translate-y-full transition-transform ${active ? 'scale-110' : 'hover:scale-105'}`}
              style={{ left, top }}
            >
              <span className="relative flex flex-col items-center">
                <span
                  className={`flex h-8 w-8 items-center justify-center rounded-full rounded-bl-none border-2 border-white text-[10px] font-bold text-white shadow-lg ${
                    active ? 'ring-4 ring-primary/25' : ''
                  }`}
                  style={{ backgroundColor: meta.color, transform: 'rotate(-45deg)' }}
                >
                  <span style={{ transform: 'rotate(45deg)' }}>{pin.name.slice(0, 2).toUpperCase()}</span>
                </span>
                {pin.mine && <span className="absolute -right-1 -top-1 h-3 w-3 rounded-full border-2 border-white bg-secondary" />}
                {(labelZoom || active) && (
                  <span className="mt-1 max-w-[140px] truncate rounded bg-white/90 px-1.5 py-0.5 text-[10px] font-bold shadow-sm">
                    {pin.name}
                  </span>
                )}
              </span>
            </button>
          );
        })}

        {/* Pin being placed */}
        {picked && (
          <span
            className="pointer-events-none absolute z-30 -translate-x-1/2 -translate-y-full"
            style={toPixels(picked)}
          >
            <span className="flex h-9 w-9 animate-bounce items-center justify-center rounded-full rounded-bl-none border-2 border-white bg-primary text-white shadow-xl" style={{ transform: 'rotate(-45deg)' }}>
              <Plus size={16} style={{ transform: 'rotate(45deg)' }} />
            </span>
          </span>
        )}

        {/* Me */}
        {me && isOnCampus(me) && (
          <span className="pointer-events-none absolute z-30 -translate-x-1/2 -translate-y-1/2" style={toPixels(me)}>
            <span className="block h-4 w-4 rounded-full border-2 border-white bg-[#1a73e8] shadow-md" />
            <span className="absolute inset-0 -z-10 m-auto block h-10 w-10 animate-ping rounded-full bg-[#1a73e8]/25" />
          </span>
        )}
      </div>

      {/* Search */}
      {chrome === 'full' && <div data-map-ui className="absolute left-3 top-3 z-40 w-[min(340px,calc(100%-6rem))]">
        <div className="flex items-center rounded-xl border border-border bg-card/95 px-3 shadow-lg backdrop-blur">
          <Search size={16} className="text-muted-foreground" />
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            data-testid="input-map-search"
            placeholder="Search a block, gate or canteen"
            className="w-full bg-transparent px-2 py-2.5 text-sm outline-none"
          />
          {query && (
            <button onClick={() => setQuery('')} aria-label="Clear search" className="text-muted-foreground hover:text-foreground">
              <X size={15} />
            </button>
          )}
        </div>
        {suggestions.length > 0 && (
          <ul className="mt-1.5 overflow-hidden rounded-xl border border-border bg-card shadow-xl">
            {suggestions.map((landmark) => (
              <li key={landmark.id}>
                <button
                  onClick={() => { setLandmarkId(landmark.id); onSelect?.(null); centerOn(landmark, 3.4); setQuery(''); }}
                  data-testid={`button-map-suggestion-${landmark.id}`}
                  className="flex w-full items-center gap-2.5 px-3 py-2.5 text-left hover:bg-muted"
                >
                  <span className="h-2.5 w-2.5 shrink-0 rounded-full" style={{ backgroundColor: CATEGORY_META[landmark.category].color }} />
                  <span className="min-w-0">
                    <span className="block truncate text-sm font-semibold">{landmark.name}</span>
                    <span className="block truncate text-xs text-muted-foreground">
                      {landmark.detail || CATEGORY_META[landmark.category].label}
                    </span>
                  </span>
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>}

      {/* Controls */}
      <div data-map-ui className="absolute bottom-4 right-3 z-40 flex flex-col gap-2">
        {chrome === 'full' && <button
          onClick={() => setShowLayers(!showLayers)}
          data-testid="button-map-layers"
          aria-label="Choose what to show"
          className="flex h-10 w-10 items-center justify-center rounded-xl border border-border bg-card shadow-lg transition hover:text-primary"
        >
          <Layers size={17} />
        </button>}
        <button
          onClick={recentre}
          data-testid="button-map-locate"
          aria-label="Recentre on me"
          className={`flex h-10 w-10 items-center justify-center rounded-xl border border-border bg-card shadow-lg transition hover:text-primary ${
            locateState === 'locating' ? 'animate-pulse text-primary' : locateState === 'here' ? 'text-[#1a73e8]' : ''
          }`}
        >
          <Crosshair size={17} />
        </button>
        <div className="overflow-hidden rounded-xl border border-border bg-card shadow-lg">
          <button
            onClick={() => zoomAround(1.4, size.width / 2, size.height / 2, true)}
            data-testid="button-map-zoom-in"
            aria-label="Zoom in"
            className="flex h-10 w-10 items-center justify-center border-b border-border transition hover:text-primary"
          >
            <Plus size={17} />
          </button>
          <button
            onClick={() => zoomAround(1 / 1.4, size.width / 2, size.height / 2, true)}
            data-testid="button-map-zoom-out"
            aria-label="Zoom out"
            className="flex h-10 w-10 items-center justify-center transition hover:text-primary"
          >
            <Minus size={17} />
          </button>
        </div>
        <button
          onClick={resetView}
          data-testid="button-map-reset"
          aria-label="Fit the whole campus"
          className="flex h-10 w-10 items-center justify-center rounded-xl border border-border bg-card shadow-lg transition hover:text-primary"
        >
          <Maximize2 size={16} />
        </button>
      </div>

      {showLayers && (
        <div data-map-ui className="absolute bottom-4 right-16 z-40 w-52 rounded-xl border border-border bg-card p-3 shadow-xl">
          <p className="mb-2 text-xs font-bold">Show on map</p>
          <div className="space-y-1.5">
            {(Object.keys(CATEGORY_META) as CampusCategory[]).map((category) => {
              const meta = CATEGORY_META[category];
              const on = !hidden.has(category);
              return (
                <label key={category} className="flex cursor-pointer items-center gap-2 text-xs">
                  <input
                    type="checkbox"
                    checked={on}
                    onChange={() => {
                      const next = new Set(hidden);
                      on ? next.add(category) : next.delete(category);
                      setHidden(next);
                    }}
                    className="accent-primary"
                  />
                  <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: meta.color }} />
                  {meta.label}
                </label>
              );
            })}
          </div>
        </div>
      )}

      {/* Where you are */}
      {chrome === 'full' && <div data-map-ui className="absolute right-3 top-3 z-40 flex max-w-[calc(100%-1.5rem)] items-center gap-2 rounded-full border border-border bg-card/95 px-3.5 py-2 text-xs font-semibold shadow-lg backdrop-blur">
        <span className={`h-2 w-2 shrink-0 rounded-full ${locateState === 'here' ? 'bg-[#1a73e8]' : locateState === 'locating' ? 'animate-pulse bg-[#1a73e8]' : 'bg-muted-foreground'}`} />
        <span className="truncate" data-testid="text-map-location-status">
          {locateState === 'locating' && 'Finding where you are…'}
          {locateState === 'here' && `You are near ${nearestLandmark(me!).landmark.name}${accuracy ? ` · ±${Math.round(accuracy)} m` : ''}`}
          {locateState === 'off-campus' && 'You are off campus · measuring from the Main Gate'}
          {locateState === 'denied' && 'Location is off · measuring from the Main Gate'}
        </span>
      </div>}

      {/* Distance readout for whatever is selected */}
      {readout && (
        <div
          data-map-ui
          className="absolute bottom-4 left-3 z-50 w-[min(340px,calc(100%-5rem))] rounded-2xl border border-border bg-card p-4 shadow-2xl"
          data-testid={`card-map-readout-${readout.id}`}
        >
          <button
            onClick={() => { onSelect?.(null); setLandmarkId(null); onClearRoute?.(); }}
            aria-label="Close"
            className="absolute right-3 top-3 text-muted-foreground hover:text-foreground"
          >
            <X size={16} />
          </button>
          <p className="font-mono-app text-[10px] uppercase tracking-[.16em]" style={{ color: CATEGORY_META[readout.category].color }}>
            {CATEGORY_META[readout.category].short}
          </p>
          <h3 className="mt-1 font-display text-lg font-bold leading-tight">{readout.name}</h3>
          {readout.detail && <p className="mt-1 text-xs text-muted-foreground">{readout.detail}</p>}
          <div className="mt-3 flex items-baseline gap-2.5 border-t border-border/80 pt-3">
            <Navigation size={15} className="shrink-0 text-primary" />
            <span className="font-display text-2xl font-bold text-primary">{formatDistance(readoutMetres)}</span>
            <span className="text-xs text-muted-foreground">{walkMinutes(readoutMetres)} min walk {fromLabel}</span>
          </div>
          {locateState === 'denied' && (
            <p className="mt-2 text-xs text-muted-foreground">Turn on location in your browser to measure from where you stand.</p>
          )}
          {selected?.body}
        </div>
      )}
    </div>
  );
}

export function useMyLocation() {
  const [point, setPoint] = useState<CampusPoint | null>(null);
  useEffect(() => {
    if (!navigator.geolocation) return;
    const id = navigator.geolocation.watchPosition(
      (position) => setPoint(latLngToPoint(position.coords.latitude, position.coords.longitude)),
      () => setPoint(null),
      { enableHighAccuracy: true },
    );
    return () => navigator.geolocation.clearWatch(id);
  }, []);
  return point;
}

export function landmarkToPin(landmark: CampusLandmark): MapPin {
  return { id: landmark.id, name: landmark.name, category: landmark.category, detail: landmark.detail, x: landmark.x, y: landmark.y };
}
