/**
 * Campus map data layer for VIT Vellore.
 *
 * Positions are stored as fractions of the campus map image (public/campus-map.jpg),
 * where x = 0 is the left edge, x = 1 the right edge, y = 0 the top edge, y = 1 the bottom.
 * Everything geographic (distance, "use my location") is derived from GEO_BOUNDS below.
 */

export type CampusCategory =
  | 'store'
  | 'food'
  | 'academic'
  | 'hostel'
  | 'sports'
  | 'parking'
  | 'gate'
  | 'service';

export interface CampusPoint {
  x: number;
  y: number;
}

export interface CampusLandmark extends CampusPoint {
  id: string;
  name: string;
  category: CampusCategory;
  /** Shown under the name in search results and pin cards. */
  detail?: string;
  /** Extra words that should match this landmark when searching. */
  aliases?: string[];
}

/**
 * Corners of the campus map image in real-world coordinates.
 *
 * Calibrated so that the Main Gate pin (x .232, y .816) lands on VIT Vellore's
 * published gate coordinate, 12.9692 N / 79.1553 E. It is close enough for
 * "how far is this from me" on foot, not for survey work. To re-calibrate:
 * stand at two known points, read their real coordinates, and adjust the four
 * numbers below until the pins line up.
 */
export const GEO_BOUNDS = { north: 12.9765, south: 12.9675, west: 79.1524, east: 79.1647 };

export const CATEGORY_META: Record<CampusCategory, { label: string; color: string; short: string }> = {
  store: { label: 'Stores', color: '#0f766e', short: 'Store' },
  food: { label: 'Food & drinks', color: '#e9a23b', short: 'Food' },
  academic: { label: 'Academic blocks', color: '#e07a68', short: 'Academic' },
  hostel: { label: 'Hostels', color: '#456a9f', short: 'Hostel' },
  sports: { label: 'Sports & open ground', color: '#4f9d69', short: 'Sports' },
  parking: { label: 'Parking', color: '#7c6ba0', short: 'Parking' },
  gate: { label: 'Gates', color: '#b4532f', short: 'Gate' },
  service: { label: 'Services', color: '#5b7a86', short: 'Service' },
};

/**
 * Landmarks traced off the Office of Students' Welfare campus map.
 * Positions are eyeballed from the printed map, so a pin can sit a few metres
 * off the door it names.
 */
export const CAMPUS_LANDMARKS: CampusLandmark[] = [
  // Gates
  { id: 'gate-main', name: 'Main Gate', category: 'gate', detail: 'Gate 1, Main Road', x: 0.232, y: 0.816, aliases: ['gate 1', 'front gate'] },
  { id: 'gate-2a', name: 'Gate 2A', category: 'gate', detail: 'Towards Katpadi station', x: 0.109, y: 0.604 },
  { id: 'gate-3a', name: 'Gate 3A', category: 'gate', detail: 'Main Road, near CBMR', x: 0.491, y: 0.871 },
  { id: 'gate-3', name: 'Gate 3', category: 'gate', detail: 'Ladies hostel entry', x: 0.397, y: 0.874, aliases: ['lh gate', 'ladies hostel gate'] },
  { id: 'gate-11', name: 'Gate 11', category: 'gate', detail: 'Mens hostel entry', x: 0.691, y: 0.923, aliases: ['mh gate'] },
  { id: 'gate-11a', name: 'Gate 11A', category: 'gate', detail: 'Near SJT', x: 0.769, y: 0.584 },
  { id: 'gate-5', name: 'Gate 5', category: 'gate', detail: 'Madras Gate, east side', x: 0.974, y: 0.406, aliases: ['madras gate'] },

  // Academic and administration
  { id: 'tt', name: 'Technology Tower', category: 'academic', detail: 'TT block', x: 0.444, y: 0.586, aliases: ['tt'] },
  { id: 'sjt', name: 'Silver Jubilee Tower', category: 'academic', detail: 'SJT block', x: 0.707, y: 0.561, aliases: ['sjt'] },
  { id: 'sjt-annex', name: 'SJT Annex', category: 'academic', x: 0.744, y: 0.578 },
  { id: 'mb', name: 'Main Block', category: 'academic', detail: 'MGR block', x: 0.227, y: 0.713, aliases: ['mgr', 'mb', 'main building'] },
  { id: 'smv', name: 'SMV Block', category: 'academic', x: 0.344, y: 0.736, aliases: ['smv'] },
  { id: 'cdmm', name: 'CDMM', category: 'academic', x: 0.190, y: 0.723 },
  { id: 'gdn', name: 'GDN Block', category: 'academic', x: 0.156, y: 0.627, aliases: ['gdn'] },
  { id: 'library', name: 'Library', category: 'academic', detail: 'Central library', x: 0.289, y: 0.711 },
  { id: 'cbmr', name: 'CBMR', category: 'academic', x: 0.479, y: 0.770 },
  { id: 'prp', name: 'Pearl Research Park', category: 'academic', detail: 'PRP', x: 0.852, y: 0.548, aliases: ['prp'] },
  { id: 'prp-annex', name: 'PRP Annex', category: 'academic', x: 0.918, y: 0.537 },
  { id: 'mgb', name: 'MGB Block', category: 'academic', x: 0.945, y: 0.455, aliases: ['m.g.b'] },
  { id: 'anna-audi', name: 'Anna Auditorium', category: 'academic', x: 0.205, y: 0.663, aliases: ['audi'] },
  { id: 'channa-audi', name: 'Channa Reddy Auditorium', category: 'academic', x: 0.254, y: 0.745 },
  { id: 'creation-lab', name: 'Creation Lab', category: 'academic', x: 0.211, y: 0.619 },
  { id: 'co2-research', name: 'CO2 Research Centre', category: 'academic', x: 0.424, y: 0.268 },

  // Mens hostel
  { id: 'mh-office', name: 'MH Office', category: 'hostel', detail: 'Mens hostel office', x: 0.453, y: 0.468 },
  { id: 'mh-a', name: 'MH A Block', category: 'hostel', x: 0.307, y: 0.379 },
  { id: 'mh-b', name: 'MH B Block', category: 'hostel', x: 0.309, y: 0.248 },
  { id: 'mh-b-annexe', name: 'MH B Annexe', category: 'hostel', x: 0.316, y: 0.157 },
  { id: 'mh-c', name: 'MH C Block', category: 'hostel', x: 0.352, y: 0.377 },
  { id: 'mh-d', name: 'MH D Block', category: 'hostel', x: 0.403, y: 0.390 },
  { id: 'mh-e', name: 'MH E Block', category: 'hostel', x: 0.478, y: 0.392 },
  { id: 'mh-f', name: 'MH F Block', category: 'hostel', x: 0.375, y: 0.290 },
  { id: 'mh-g', name: 'MH G Block', category: 'hostel', x: 0.477, y: 0.356 },
  { id: 'mh-h', name: 'MH H Block', category: 'hostel', x: 0.309, y: 0.451 },
  { id: 'mh-j', name: 'MH J Block', category: 'hostel', x: 0.320, y: 0.433 },
  { id: 'mh-k', name: 'MH K Block', category: 'hostel', x: 0.564, y: 0.427 },
  { id: 'mh-l', name: 'MH L Block', category: 'hostel', x: 0.648, y: 0.411 },
  { id: 'mh-m', name: 'MH M Block', category: 'hostel', x: 0.715, y: 0.421 },
  { id: 'mh-n', name: 'MH N Block', category: 'hostel', x: 0.727, y: 0.186 },
  { id: 'mh-p', name: 'MH P Block', category: 'hostel', x: 0.715, y: 0.312 },
  { id: 'mh-q', name: 'MH Q Block', category: 'hostel', x: 0.681, y: 0.277 },
  { id: 'mh-r', name: 'MH R Block', category: 'hostel', x: 0.656, y: 0.358 },
  { id: 'mh-t', name: 'MH T Block', category: 'hostel', x: 0.820, y: 0.207 },

  // Ladies hostel
  { id: 'lh-office', name: 'LH Office', category: 'hostel', detail: 'Ladies hostel office', x: 0.617, y: 0.525 },
  { id: 'lh-a', name: 'LH A Block', category: 'hostel', x: 0.363, y: 0.796 },
  { id: 'lh-b', name: 'LH B Block', category: 'hostel', x: 0.367, y: 0.825 },
  { id: 'lh-c', name: 'LH C Block', category: 'hostel', x: 0.518, y: 0.567 },
  { id: 'lh-d', name: 'LH D Block', category: 'hostel', x: 0.563, y: 0.556 },
  { id: 'lh-e', name: 'LH E Block', category: 'hostel', x: 0.605, y: 0.561 },
  { id: 'lh-e-annex', name: 'LH E Annex', category: 'hostel', x: 0.648, y: 0.584 },
  { id: 'lh-g', name: 'LH G Block', category: 'hostel', x: 0.448, y: 0.813 },
  { id: 'lh-h', name: 'LH H Block', category: 'hostel', x: 0.432, y: 0.863 },
  { id: 'lh-i', name: 'LH I Block', category: 'hostel', x: 0.415, y: 0.808 },
  { id: 'lh-s', name: 'LH S Block', category: 'hostel', x: 0.836, y: 0.274 },

  // Food
  { id: 'food-court', name: 'Food Courts', category: 'food', detail: 'Near VIT Lake', x: 0.430, y: 0.651 },
  { id: 'foodys-main', name: 'Foodys', category: 'food', detail: 'Near Greenos', x: 0.395, y: 0.743 },
  { id: 'foodys-sjt', name: 'Foodys (SJT)', category: 'food', x: 0.746, y: 0.628 },
  { id: 'greenos', name: 'Greenos', category: 'food', x: 0.391, y: 0.691 },
  { id: 'gdn-canteen', name: 'GDN Canteen', category: 'food', x: 0.148, y: 0.595 },
  { id: 'nescafe-mb', name: 'Nescafe (Main Block)', category: 'food', x: 0.305, y: 0.660 },
  { id: 'nescafe-mh', name: 'Nescafe (MH K)', category: 'food', x: 0.602, y: 0.406 },
  { id: 'just-bake', name: 'Just Bake', category: 'food', x: 0.438, y: 0.416 },
  { id: 'chillout-plaza', name: 'Chillout Plaza', category: 'food', detail: 'Mens hostel side', x: 0.748, y: 0.342 },
  { id: 'mayflower', name: 'Mayflower Shops', category: 'food', x: 0.547, y: 0.449 },

  // Stores and services
  { id: 'central-store', name: 'Central Store', category: 'store', detail: 'Near GDN', x: 0.180, y: 0.595, aliases: ['mb store'] },
  { id: 'optical-store', name: 'Optical Store', category: 'store', x: 0.391, y: 0.577 },
  { id: 'stationery-tt', name: 'Stationery (TT)', category: 'store', x: 0.406, y: 0.553 },
  { id: 'medical-store', name: 'Medical Store', category: 'service', detail: 'Pharmacy near TT', x: 0.397, y: 0.548 },
  { id: 'health-centre', name: 'Health Centre', category: 'service', x: 0.164, y: 0.685 },
  { id: 'atm-mb', name: 'ATM (Main Block)', category: 'service', x: 0.156, y: 0.668 },
  { id: 'laundry', name: 'Old Laundry', category: 'service', detail: 'Mens hostel side', x: 0.437, y: 0.449 },
  { id: 'cycle-rent', name: 'Cycle Rent', category: 'service', x: 0.789, y: 0.370 },
  { id: 'sw-office', name: "Students' Welfare Office", category: 'service', detail: 'SW Office', x: 0.913, y: 0.533 },
  { id: 'powerhouse', name: 'Powerhouse', category: 'service', x: 0.703, y: 0.596 },

  // Sports and open space
  { id: 'vit-lake', name: 'VIT Lake', category: 'sports', x: 0.509, y: 0.686 },
  { id: 'sjt-ground', name: 'SJT Ground', category: 'sports', detail: 'Induction venue', x: 0.673, y: 0.679 },
  { id: 'open-stadium', name: 'Open Stadium', category: 'sports', x: 0.504, y: 0.170 },
  { id: 'indoor-stadium', name: 'Indoor Stadium', category: 'sports', x: 0.406, y: 0.498 },
  { id: 'swimming-pool', name: 'Swimming Pool', category: 'sports', x: 0.500, y: 0.263 },
  { id: 'gym-block', name: 'Gym & Table Tennis', category: 'sports', x: 0.438, y: 0.120 },
  { id: 'basketball', name: 'Basketball Court', category: 'sports', x: 0.365, y: 0.652 },
  { id: 'vit-fields', name: 'VIT Fields', category: 'sports', x: 0.895, y: 0.352 },

  // Parking
  { id: 'woodys-parking', name: 'Woodys Parking', category: 'parking', x: 0.322, y: 0.624 },
  { id: 'bike-parking-cbmr', name: 'Bike Parking (CBMR)', category: 'parking', x: 0.520, y: 0.811 },
  { id: 'bike-parking-east', name: 'Bike Parking (East)', category: 'parking', x: 0.784, y: 0.696 },
  { id: 'car-parking-east', name: 'Car Parking (East)', category: 'parking', x: 0.779, y: 0.748 },
  { id: 'parking-mb', name: 'Parking (Main Block)', category: 'parking', x: 0.180, y: 0.756 },
  { id: 'parking-mht', name: 'Parking (MH T)', category: 'parking', x: 0.773, y: 0.228 },
];

export const LANDMARKS_BY_ID = new Map(CAMPUS_LANDMARKS.map((item) => [item.id, item]));

/* ------------------------------------------------------------------ */
/* Geometry                                                            */
/* ------------------------------------------------------------------ */

const METRES_PER_DEG_LAT = 110574;

function metresPerDegLng(lat: number) {
  return 111320 * Math.cos((lat * Math.PI) / 180);
}

export function pointToLatLng(point: CampusPoint) {
  return {
    lat: GEO_BOUNDS.north - point.y * (GEO_BOUNDS.north - GEO_BOUNDS.south),
    lng: GEO_BOUNDS.west + point.x * (GEO_BOUNDS.east - GEO_BOUNDS.west),
  };
}

export function latLngToPoint(lat: number, lng: number): CampusPoint {
  return {
    x: (lng - GEO_BOUNDS.west) / (GEO_BOUNDS.east - GEO_BOUNDS.west),
    y: (GEO_BOUNDS.north - lat) / (GEO_BOUNDS.north - GEO_BOUNDS.south),
  };
}

export function isOnCampus(point: CampusPoint) {
  return point.x >= -0.04 && point.x <= 1.04 && point.y >= -0.04 && point.y <= 1.04;
}

/** Straight-line distance between two map points, in metres. */
export function metresBetween(a: CampusPoint, b: CampusPoint) {
  const first = pointToLatLng(a);
  const second = pointToLatLng(b);
  const midLat = (first.lat + second.lat) / 2;
  const dy = (first.lat - second.lat) * METRES_PER_DEG_LAT;
  const dx = (first.lng - second.lng) * metresPerDegLng(midLat);
  return Math.sqrt(dx * dx + dy * dy);
}

export function formatDistance(metres: number) {
  if (metres < 950) return `${Math.round(metres / 10) * 10} m`;
  return `${(metres / 1000).toFixed(1)} km`;
}

/** Campus paths bend, so pad the straight line a little before estimating a walk. */
export function walkMinutes(metres: number) {
  const walked = metres * 1.25;
  return Math.max(1, Math.round(walked / 75));
}

export function nearestLandmark(point: CampusPoint, categories?: CampusCategory[]) {
  const pool = categories ? CAMPUS_LANDMARKS.filter((item) => categories.includes(item.category)) : CAMPUS_LANDMARKS;
  let best = pool[0];
  let bestDistance = Infinity;
  for (const landmark of pool) {
    const distance = metresBetween(point, landmark);
    if (distance < bestDistance) {
      best = landmark;
      bestDistance = distance;
    }
  }
  return { landmark: best, metres: bestDistance };
}

/** "Next to Foodys, about 40 m east" — used to label a dropped pin. */
export function describePoint(point: CampusPoint) {
  const { landmark, metres } = nearestLandmark(point);
  if (metres < 35) return `At ${landmark.name}`;
  const dy = point.y - landmark.y;
  const dx = point.x - landmark.x;
  const compass = Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? 'east' : 'west') : dy > 0 ? 'south' : 'north';
  return `${formatDistance(metres)} ${compass} of ${landmark.name}`;
}

export function searchLandmarks(query: string, limit = 8) {
  const needle = query.trim().toLowerCase();
  if (!needle) return [];
  return CAMPUS_LANDMARKS.map((landmark) => {
    const name = landmark.name.toLowerCase();
    const haystack = [name, landmark.detail || '', ...(landmark.aliases || [])].join(' ').toLowerCase();
    let score = -1;
    if (name.startsWith(needle)) score = 0;
    else if (name.includes(needle)) score = 1;
    else if (haystack.includes(needle)) score = 2;
    return { landmark, score };
  })
    .filter((entry) => entry.score >= 0)
    .sort((a, b) => a.score - b.score || a.landmark.name.localeCompare(b.landmark.name))
    .slice(0, limit)
    .map((entry) => entry.landmark);
}

/**
 * Best-effort match from a written location ("Silver Jubilee Tower", "MB Store,
 * Ground Floor") to a landmark, so directory entries land on the map before
 * anyone has pinned them by hand.
 */
export function matchLandmark(text?: string): CampusLandmark | null {
  if (!text) return null;
  const needle = text.toLowerCase();
  let best: CampusLandmark | null = null;
  let bestLength = 0;
  for (const landmark of CAMPUS_LANDMARKS) {
    for (const candidate of [landmark.name, ...(landmark.aliases || [])]) {
      const token = candidate.toLowerCase();
      if (token.length > bestLength && needle.includes(token)) {
        best = landmark;
        bestLength = token.length;
      }
    }
  }
  return best;
}

/* ------------------------------------------------------------------ */
/* Store locations pinned by people using the app                      */
/* ------------------------------------------------------------------ */

export interface PinnedStore extends CampusPoint {
  id: string;
  name: string;
  category: CampusCategory;
  /** Free text the owner typed, e.g. "SJT ground floor, next to the ATM". */
  note?: string;
  hours?: string;
  phone?: string;
  /** Landmark description generated when the pin was dropped. */
  place: string;
  createdAt: string;
  /** Set when the pin belongs to a store already in the directory. */
  storeId?: number;
}

const STORAGE_KEY = 'vitmarket.pinned-stores.v1';
const listeners = new Set<() => void>();
let cache: PinnedStore[] | null = null;

function read(): PinnedStore[] {
  if (cache) return cache;
  if (typeof window === 'undefined') return [];
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    cache = raw ? (JSON.parse(raw) as PinnedStore[]) : [];
  } catch {
    cache = [];
  }
  return cache;
}

function write(next: PinnedStore[]) {
  cache = next;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
  } catch {
    /* A full or blocked storage should not break the map. */
  }
  listeners.forEach((listener) => listener());
}

export const pinnedStores = {
  list: read,
  subscribe(listener: () => void) {
    listeners.add(listener);
    return () => listeners.delete(listener);
  },
  add(input: Omit<PinnedStore, 'id' | 'createdAt' | 'place'> & { place?: string }) {
    const record: PinnedStore = {
      ...input,
      place: input.place || describePoint(input),
      id: `pin-${Date.now().toString(36)}`,
      createdAt: new Date().toISOString(),
    };
    write([...read(), record]);
    return record;
  },
  update(id: string, patch: Partial<PinnedStore>) {
    write(read().map((item) => (item.id === id ? { ...item, ...patch } : item)));
  },
  remove(id: string) {
    write(read().filter((item) => item.id !== id));
  },
};
