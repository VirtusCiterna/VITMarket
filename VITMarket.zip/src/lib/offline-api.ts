import { demoHome, demoListings, demoProducts, demoStores } from '../App';

type AnyRecord = Record<string, any>;

const labProducts = [
  { id: 106, name: 'Breadboard 830 Tie-Point', description: 'Core prototyping board for electronics lab builds.', category: 'Electronics', price: 180, compareAt: 220, stock: 12, stockStatus: 'In Stock', storeId: 4, storeName: 'Tech Stop', location: 'Technology Tower', distance: 1.4, image: '', popularity: 96, tags: ['lab', 'electronics', 'prototype'] },
  { id: 107, name: 'Jumper Wires (65 pc)', description: 'Male-to-male, male-to-female, and female-to-female wires.', category: 'Electronics', price: 95, compareAt: null, stock: 28, stockStatus: 'In Stock', storeId: 4, storeName: 'Tech Stop', location: 'Technology Tower', distance: 1.4, image: '', popularity: 94, tags: ['lab', 'wires'] },
  { id: 108, name: '1/4 Watt Resistor Kit', description: 'A practical kit of common resistor values.', category: 'Lab Equipment', price: 140, compareAt: null, stock: 6, stockStatus: 'Low Stock', storeId: 4, storeName: 'Tech Stop', location: 'Technology Tower', distance: 1.4, image: '', popularity: 92, tags: ['lab', 'resistors'] },
  { id: 109, name: 'LED Pack — 5mm assorted', description: 'Assorted red, green, blue, and yellow LEDs.', category: 'Lab Equipment', price: 75, compareAt: null, stock: 22, stockStatus: 'In Stock', storeId: 4, storeName: 'Tech Stop', location: 'Technology Tower', distance: 1.4, image: '', popularity: 90, tags: ['lab', 'led'] },
];

const products: AnyRecord[] = [...demoProducts, ...labProducts];
const stores: AnyRecord[] = [...demoStores];
const listings: AnyRecord[] = [...demoListings];
const favoriteProducts = new Set<number>([104]);
const favoriteStores = new Set<number>([1]);
const favoriteListings = new Set<number>([203]);

const savedProduct = (product: AnyRecord) => ({ ...product, saved: favoriteProducts.has(product.id) });
const savedListing = (listing: AnyRecord) => ({ ...listing, saved: favoriteListings.has(listing.id) });
const categoryMatches = (value: string, category?: string) =>
  !category || category === 'all' || value.toLowerCase().replaceAll(' ', '-') === category.toLowerCase();
const bodyOf = (init?: RequestInit) => {
  if (!init?.body || typeof init.body !== 'string') return {};
  try { return JSON.parse(init.body) as AnyRecord; } catch { return {}; }
};
const response = (payload: unknown, status = 200) => new Response(JSON.stringify(payload), {
  status,
  headers: { 'content-type': 'application/json' },
});

function handleRequest(input: RequestInfo | URL, init?: RequestInit): Response {
  const requestUrl = new URL(typeof input === 'string' ? input : input instanceof URL ? input.href : input.url, window.location.href);
  const path = requestUrl.pathname.replace(/^.*?\/api(?=\/|$)/, '');
  const method = (init?.method || (input instanceof Request ? input.method : 'GET')).toUpperCase();
  const query = requestUrl.searchParams;

  if (path === '/healthz') return response({ status: 'ok', mode: 'offline' });
  if (path === '/home') {
    return response({
      ...demoHome,
      nearbyStores: stores,
      popularProducts: products.slice(0, 6).map(savedProduct),
      recommended: products.slice(2, 6).map(savedProduct),
      recentlyViewed: products.slice(1, 5).map(savedProduct),
      marketplace: listings.map(savedListing),
    });
  }
  if (path === '/products' && method === 'GET') {
    const search = (query.get('search') || '').toLowerCase();
    const category = query.get('category') || undefined;
    const storeId = Number(query.get('storeId') || 0);
    const availability = query.get('availability') || 'all';
    return response(products
      .filter((product) => !storeId || product.storeId === storeId)
      .filter((product) => categoryMatches(product.category, category))
      .filter((product) => !search || [product.name, product.description, product.category, ...product.tags].join(' ').toLowerCase().includes(search))
      .filter((product) => availability === 'all' || (availability === 'in_stock' && product.stockStatus === 'In Stock') || (availability === 'low_stock' && product.stockStatus === 'Low Stock') || (availability === 'out_of_stock' && product.stockStatus === 'Out of Stock'))
      .map(savedProduct));
  }
  if (path.startsWith('/products/') && method === 'GET') {
    const product = products.find((item) => item.id === Number(path.split('/').pop()));
    if (!product) return response({ error: 'Product not found' }, 404);
    return response({
      ...savedProduct(product),
      related: products.filter((item) => item.id !== product.id && item.category === product.category).slice(0, 4).map(savedProduct),
      marketplaceAlternatives: listings.filter((item) => item.category === product.category).slice(0, 3).map(savedListing),
    });
  }
  if (path === '/stores' && method === 'GET') return response(stores);
  if (path.startsWith('/stores/') && method === 'GET') {
    const store = stores.find((item) => item.id === Number(path.split('/').pop()));
    if (!store) return response({ error: 'Store not found' }, 404);
    return response({ ...store, products: products.filter((product) => product.storeId === store.id).map(savedProduct) });
  }
  if (path === '/search' && method === 'GET') {
    const search = (query.get('q') || '').trim();
    const normalized = search.toLowerCase();
    const bundleSearch = ['lab', 'kit', 'tomorrow', 'everything'].some((term) => normalized.includes(term));
    const bundleProducts = labProducts;
    const matchingProducts = bundleSearch
      ? bundleProducts
      : products.filter((product) => [product.name, product.description, product.category, ...product.tags].join(' ').toLowerCase().includes(normalized));
    const matchingListings = listings.filter((listing) => !search || `${listing.title} ${listing.description} ${listing.category}`.toLowerCase().includes(normalized));
    return response({
      query: search,
      interpretation: bundleSearch ? 'A practical electronics lab bundle with parts available on campus.' : search ? `Showing products and student listings related to “${search}”.` : 'Search the campus marketplace and nearby stores.',
      products: matchingProducts.slice(0, 12).map(savedProduct),
      listings: (bundleSearch ? [...matchingListings, ...listings.filter((listing) => listing.category === 'Electronics')] : matchingListings).slice(0, 8).map(savedListing),
      stores: (bundleSearch ? stores.filter((store) => store.categories.includes('Electronics')) : stores.filter((store) => `${store.name} ${store.description} ${store.location}`.toLowerCase().includes(normalized))).slice(0, 3),
      bundle: bundleSearch ? {
        title: 'Electronics lab kit',
        note: 'Everything you need for tomorrow’s electronics lab.',
        total: bundleProducts.reduce((sum, product) => sum + product.price, 0),
        completeAtStore: 'Tech Stop',
        items: bundleProducts.map((product) => ({ name: product.name, product: savedProduct(product), available: product.stock > 0 })),
      } : null,
    });
  }
  if (path === '/marketplace' && method === 'GET') {
    const search = (query.get('search') || '').toLowerCase();
    const category = query.get('category') || undefined;
    return response(listings.filter((listing) => categoryMatches(listing.category, category)).filter((listing) => !search || `${listing.title} ${listing.description} ${listing.category}`.toLowerCase().includes(search)).map(savedListing));
  }
  if (path === '/marketplace' && method === 'POST') {
    const input = bodyOf(init);
    const listing = { id: Math.max(0, ...listings.map((item) => item.id)) + 1, title: input.title || 'New marketplace listing', description: input.description || '', price: Number(input.price || 0), condition: input.condition || 'Good', category: input.category || 'Other', pickupLocation: input.pickupLocation || 'Student Plaza', seller: 'You', createdAt: 'Just now', image: '', saved: false };
    listings.unshift(listing);
    return response(savedListing(listing), 201);
  }
  if (path === '/favorites' && method === 'GET') return response({ products: products.filter((item) => favoriteProducts.has(item.id)).map(savedProduct), stores: stores.filter((item) => favoriteStores.has(item.id)), listings: listings.filter((item) => favoriteListings.has(item.id)).map(savedListing) });
  if (path === '/favorites' && method === 'POST') {
    const input = bodyOf(init);
    const collection = input.type === 'product' ? favoriteProducts : input.type === 'store' ? favoriteStores : favoriteListings;
    const itemId = Number(input.itemId);
    const saved = collection.has(itemId);
    if (saved) collection.delete(itemId); else collection.add(itemId);
    return response({ type: input.type, itemId, saved: !saved });
  }
  if (path === '/analytics/owner' && method === 'GET') {
    return response({
      totalProducts: products.length,
      lowStock: products.filter((product) => product.stock <= 5).length,
      todaysSearches: 148,
      trendingProducts: 7,
      demandByDay: [{ day: 'Mon', searches: 96 }, { day: 'Tue', searches: 118 }, { day: 'Wed', searches: 132 }, { day: 'Thu', searches: 151 }, { day: 'Fri', searches: 184 }, { day: 'Sat', searches: 162 }, { day: 'Sun', searches: 141 }],
      categories: [{ label: 'Electronics', value: 412, change: 18, status: 'Rising' }, { label: 'Books', value: 278, change: 8, status: 'Steady' }, { label: 'Lab Equipment', value: 214, change: 24, status: 'High demand' }, { label: 'Stationery', value: 172, change: -3, status: 'Steady' }],
      products: [{ label: 'Scientific calculators', value: 64, change: 31, status: 'HIGH DEMAND' }, { label: 'Electronics lab kits', value: 52, change: 27, status: 'RISING DEMAND' }, { label: 'Jumper wires', value: 39, change: 14, status: 'RISING DEMAND' }, { label: 'Engineering textbooks', value: 34, change: 6, status: 'STEADY' }],
    });
  }
  if (path === '/owner/products' && method === 'POST') {
    const input = bodyOf(init);
    const store = stores.find((item) => item.id === Number(input.storeId)) || stores[0];
    const stock = Number(input.stock || 0);
    const product = { id: Math.max(0, ...products.map((item) => item.id)) + 1, name: input.name || 'New product', description: input.description || '', category: input.category || 'Other', price: Number(input.price || 0), compareAt: null, stock, stockStatus: stock === 0 ? 'Out of Stock' : stock <= 5 ? 'Low Stock' : 'In Stock', storeId: store.id, storeName: store.name, location: store.location, distance: store.distance, image: '', popularity: 20, tags: [] };
    products.push(product);
    return response(savedProduct(product), 201);
  }
  if (path.startsWith('/owner/products/') && (method === 'PATCH' || method === 'DELETE')) {
    const id = Number(path.split('/').pop());
    const index = products.findIndex((item) => item.id === id);
    if (index < 0) return response({ error: 'Product not found' }, 404);
    if (method === 'DELETE') { products.splice(index, 1); return new Response(null, { status: 204 }); }
    Object.assign(products[index], bodyOf(init));
    products[index].stockStatus = products[index].stock === 0 ? 'Out of Stock' : products[index].stock <= 5 ? 'Low Stock' : 'In Stock';
    return response(savedProduct(products[index]));
  }
  return response({ error: 'Offline route not found' }, 404);
}

export function installOfflineApi() {
  const browser = globalThis as typeof globalThis & { __vitmarketOfflineApi?: boolean; fetch: typeof fetch };
  if (browser.__vitmarketOfflineApi) return;
  const originalFetch = browser.fetch.bind(browser);
  browser.fetch = async (input, init) => {
    const url = typeof input === 'string' ? input : input instanceof URL ? input.href : input.url;
    if (url.includes('/api/')) return handleRequest(input, init);
    return originalFetch(input, init);
  };
  browser.__vitmarketOfflineApi = true;
}