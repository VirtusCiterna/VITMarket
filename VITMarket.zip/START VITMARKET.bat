@echo off
setlocal
cd /d "%~dp0"
echo.
echo ==========================================
echo          VITMarket Offline
echo ==========================================
echo.
echo Starting the local website...
echo.

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0VITMarket-Server.ps1"

echo.
echo VITMarket has stopped.
pause
